# MetrAIyux 0S Public Spectacle Website

This is a separate public-facing website built to explain and sell the MetrAIyux 0S platform. It is not the protected admin/customer operating app.

## Pages
- index.html — spectacle homepage
- guided-tour.html — systematic walkthrough
- platform.html — full platform overview
- tech-stack.html — stack and deployment model
- brain-system.html — 16-brain architecture
- security.html — tenant isolation and 0meg4kAI
- value.html — value case
- fit-check.html — interactive qualification questionnaire
- download.html — share packet export
- operator-notes.html — public/private deployment boundary

## Deploy
Drop this folder on Netlify, Cloudflare Pages, or any static host. Keep the real MetrAIyux 0S admin app protected separately.
