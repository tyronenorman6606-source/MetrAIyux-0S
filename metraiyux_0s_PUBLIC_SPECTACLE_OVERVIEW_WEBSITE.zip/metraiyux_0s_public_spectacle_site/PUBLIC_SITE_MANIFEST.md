# MetrAIyux 0S Public Spectacle Site Manifest

Generated: 2026-05-15T12:05:14.975040Z

Purpose: A live public website that describes, sells, and systematically explains the MetrAIyux 0S platform.

Includes: spectacle homepage, guided tour, tech stack overview, brain architecture, security model, value case, fit questionnaire, share packet export, and operator boundary notes.

Logo assets: transparent floating logo, transparent emblem, gold-blue poster.
